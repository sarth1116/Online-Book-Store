const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Define the Book schema and model directly in this file
const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  price: Number,
  quantity: Number
});

const Book = mongoose.model('Book', bookSchema);

mongoose.connect('mongodb://localhost:27017/bookMart', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  console.log('Connected to MongoDB');

  const booksPath = path.join(__dirname, 'books.json');
  const booksData = JSON.parse(fs.readFileSync(booksPath, 'utf8'));

  try {
    await Book.deleteMany({}); // Clear existing data
    await Book.insertMany(booksData); // Insert new data
    console.log('Books data inserted');
  } catch (err) {
    console.error('Error inserting books data:', err);
  } finally {
    mongoose.disconnect();
  }
}).catch(err => {
  console.error('Failed to connect to MongoDB', err);
});
