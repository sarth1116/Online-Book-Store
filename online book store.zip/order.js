// order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  items: [{
    bookId: mongoose.Schema.Types.ObjectId,
    title: String,
    price: Number,
    quantity: Number
  }],
  totalAmount: Number,
  date: { type: Date, default: Date.now }
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order; 
