const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');

// Define the Book schema and model
const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  price: Number,
  quantity: Number
});

const Book = mongoose.model('Book', bookSchema);

// Define the Order schema and model
const orderSchema = new mongoose.Schema({
  items: [{
    bookId: mongoose.Schema.Types.ObjectId,
    title: String,
    price: Number,
    quantity: Number
  }],
  totalAmount: Number,
  date: { type: Date, default: Date.now }
});

const Order = mongoose.model('Order', orderSchema);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/bookMart')
.then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('Failed to connect to MongoDB', err);
});

// Routes
app.get('/', async (req, res) => {
  try {
    const books = await Book.find({});
    res.render('index', { books });
  } catch (err) {
    res.status(500).send('Error fetching books');
  }
});

app.get('/books/:id', async (req, res) => {
  const bookId = req.params.id;
  try {
    const book = await Book.findById(bookId);
    if (!book) {
      return res.status(404).send('Book not found.');
    }
    res.render('book-details', { book });
  } catch (err) {
    res.status(500).send('Error fetching book details');
  }
});

let shoppingCart = [];

app.get('/cart', (req, res) => {
  res.render('cart', { cart: shoppingCart });
});

app.post('/cart/add', async (req, res) => {
  const bookId = req.body.bookId;
  const quantity = parseInt(req.body.quantity);

  try {
    const book = await Book.findById(bookId);
    if (!book) {
      return res.status(404).send('Book not found.');
    }

    if (quantity > book.quantity) {
      return res.status(400).send('Not enough stock.');
    }

    const cartItem = shoppingCart.find(item => item.bookId.toString() === bookId);
    if (cartItem) {
      cartItem.quantity += quantity;
    } else {
      shoppingCart.push({
        bookId,
        title: book.title,
        price: book.price,
        quantity
      });
    }

    res.redirect('/cart');
  } catch (err) {
    res.status(500).send('Error adding to cart');
  }
});

app.post('/cart/remove', (req, res) => {
  const bookId = req.body.bookId;
  shoppingCart = shoppingCart.filter(item => item.bookId.toString() !== bookId);
  res.redirect('/cart');
});

app.get('/checkout', async (req, res) => {
  try {
    const totalAmount = shoppingCart.reduce((total, item) => total + item.price * item.quantity, 0);
    const order = new Order({
      items: shoppingCart,
      totalAmount
    });

    await order.save();
    shoppingCart = []; // Clear the shopping cart
    res.render('checkout');
  } catch (err) {
    res.status(500).send('Error saving order');
  }
});
app.get('/search', async (req, res) => {
  const query = req.query.query;
  try {
    const books = await Book.find({
      $or: [
        { title: { $regex: query, $options: 'i' } },
        { author: { $regex: query, $options: 'i' } }
      ]
    });
    res.render('index', { books }); // Render the index template with search results
  } catch (err) {
    res.status(500).send('Error searching for books');
  }
});

app.use((req, res) => {
  res.status(404).send('Page not found.');
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
